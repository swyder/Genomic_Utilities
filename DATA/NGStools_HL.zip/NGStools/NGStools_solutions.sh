#!/bin/bash

###########################
# URPP Evolution in Action tutorial:
# NGS tools
#
# Date: November 2015
# @author: Heidi Tschanz-Lischer
###########################

# set variables
progSeqtk=/home/students/software/seqtk-master/seqtk

read=ERR000064_200
ref=hs37d5_chr19.fa

vcf=chr18-19.phase3.vcf
pop1=British.txt
pop2=HanChineseSouth.txt
###############


# Exercises FASTQ: ###########

# Exercise 1:
$progSeqtk fqchk ${read}_1.fastq > ${read}_1_qc.txt
$progSeqtk fqchk ${read}_2.fastq > ${read}_2_qc.txt


# Exercise 2:
# You have to put the names from the forward and reverse reads
# in seperate files else reads are duplicated (everything after
# the first whitespace in the header is ignored by seqtk)
failed1=failedReads_1.txt
echo "ERR000064.19 BGI-FC20CNLAAXX_7_1_944:632/1" > $failed1
echo "ERR000064.336257 BGI-FC20CNLAAXX_7_14_339:916/1" >> $failed1
echo "ERR000064.346608 BGI-FC20CNLAAXX_7_14_977:474/1" >> $failed1
echo "ERR000064.521728 BGI-FC20CNLAAXX_7_22_625:861/1" >> $failed1
echo "ERR000064.521729 BGI-FC20CNLAAXX_7_22_380:228/1" >> $failed1
echo "ERR000064.602263 BGI-FC20CNLAAXX_7_25_860:760/1" >> $failed1

failed2=failedReads_2.txt
echo "ERR000064.406739 BGI-FC20CNLAAXX_7_17_574:189/2" > $failed2
echo "ERR000064.406740 BGI-FC20CNLAAXX_7_17_533:077/2" >> $failed2
echo "ERR000064.521729 BGI-FC20CNLAAXX_7_22_380:228/2" >> $failed2
echo "ERR000064.534039 BGI-FC20CNLAAXX_7_22_400:333/2" >> $failed2

 # extract reads
$progSeqtk subseq ${read}_1.fastq $failed1 > ${failed1%.txt}.fq
$progSeqtk subseq ${read}_2.fastq $failed2 > ${failed2%.txt}.fq

 # convert FASTQ to FASTA and save it to one FASTA file
$progSeqtk seq -A ${failed1%.txt}.fq > ${failed1%_1.txt}.fa
$progSeqtk seq -A ${failed2%.txt}.fq >> ${failed1%_1.txt}.fa


# Exercise 3:
$progSeqtk mergepe ${read}_1.fastq ${read}_2.fastq > ${read}.fq


# Exercise 4:
# use the same random seed to keep pairing
$progSeqtk sample -s100 ${read}_1.fastq 1000 > ${read}_sub_1.fq
$progSeqtk sample -s100 ${read}_2.fastq 1000 > ${read}_sub_2.fq




# Exercises VCF: ###########

# Exercise 1:
# only SNPs, thus use --remove-indels
vcfChr19Short=chr19_short.phase3
vcftools --gzvcf ${vcf}.gz --remove-indels --chr 19 --from-bp 1 --to-bp 10000000 --recode --out ${vcfChr19Short}


# Exercise 2:
vcftools --vcf ${vcfChr19Short}.recode.vcf --keep British.txt --mac 1 --recode --out ${vcfChr19Short}_British
vcftools --vcf ${vcfChr19Short}.recode.vcf --keep HanChineseSouth.txt --mac 1 --recode --out ${vcfChr19Short}_HanChineseSouth


# Exercise 3:
vcftools --vcf ${vcfChr19Short}_British.recode.vcf --diff ${vcfChr19Short}_HanChineseSouth.recode.vcf --diff-site --out diffSites


# Exercise 4:
#vcf need to be compressed with bgzip and indexed with tabix
bgzip -c ${vcfChr19Short}_British.recode.vcf > ${vcfChr19Short}_British.recode.vcf.gz
bgzip -c ${vcfChr19Short}_HanChineseSouth.recode.vcf > ${vcfChr19Short}_HanChineseSouth.recode.vcf.gz
tabix -p vcf ${vcfChr19Short}_British.recode.vcf.gz
tabix -p vcf ${vcfChr19Short}_HanChineseSouth.recode.vcf.gz

bcftools merge ${vcfChr19Short}_British.recode.vcf.gz ${vcfChr19Short}_HanChineseSouth.recode.vcf.gz -O v -o ${vcfChr19Short}_merged.vcf


# Exercise 5:
vcfChr19=chr19.phase3
#vcf need to be compressed with bgzip and indexed with tabix
vcftools --gzvcf ${vcf}.gz --chr 19 --keep British.txt --remove-indels --recode --stdout | bgzip -c > ${vcfChr19}_British.vcf.gz
vcftools --gzvcf ${vcf}.gz --chr 19 --keep HanChineseSouth.txt --remove-indels --recode --stdout | bgzip -c > ${vcfChr19}_HanChineseSouth.vcf.gz
tabix -p vcf ${vcfChr19}_British.vcf.gz
tabix -p vcf ${vcfChr19}_HanChineseSouth.vcf.gz

bcftools consensus --iupac-codes -f hs37d5_chr19.fa ${vcfChr19}_British.vcf.gz -o ${vcfChr19}_British.fa
bcftools consensus --iupac-codes -f hs37d5_chr19.fa ${vcfChr19}_HanChineseSouth.vcf.gz -o ${vcfChr19}_HanChineseSouth.fa

$progSeqtk seq -r ${vcfChr19}_British.fa > ${vcfChr19}_British_rc.fa
$progSeqtk seq -r ${vcfChr19}_HanChineseSouth.fa > ${vcfChr19}_HanChineseSouth_rc.fa


# Exercise 6:
vcfChr18=chr18.phase3
wsize=100000
wstep=50000
vcftools --gzvcf ${vcf}.gz --remove-indels --chr 18 --weir-fst-pop British.txt --weir-fst-pop HanChineseSouth.txt \
         --fst-window-size $wsize --fst-window-step $wstep --out $vcfChr18
         
vcftools --gzvcf ${vcf}.gz --keep British.txt --remove-indels --chr 18 --window-pi $wsize --window-pi-step $wstep --out ${vcfChr18}_British
vcftools --gzvcf ${vcf}.gz --keep HanChineseSouth.txt --remove-indels --chr 18 --window-pi $wsize --window-pi-step $wstep --out ${vcfChr18}_HanChineseSouth

R
  dataFst <- read.table("chr18.phase3.windowed.weir.fst", header=TRUE)
  dataFst$BIN_AVERAGE <- apply(dataFst[,c("BIN_START", "BIN_END")],1, mean)
  dataPiBritish <- read.table("chr18.phase3_British.windowed.pi", header=TRUE)
  dataPiBritish$BIN_AVERAGE <- apply(dataPiBritish[,c("BIN_START", "BIN_END")],1, mean)
  dataPiChinese <- read.table("chr18.phase3_HanChineseSouth.windowed.pi", header=TRUE)
  dataPiChinese$BIN_AVERAGE <- apply(dataPiChinese[,c("BIN_START", "BIN_END")],1, mean)
  
  png("FST_slidingWindow.png", bg="transparent", width=1600, height=800) 
    par(mfrow=c(2,1))
    plot(dataFst$BIN_AVERAGE, dataFst$WEIGHTED_FST, xlab="position [bp]", 
         ylab="weighted FST", main="Chromosome 18", type="l")
    plot(dataPiBritish$BIN_AVERAGE, dataPiBritish$PI, xlab="position [bp]", ylab="Pi", type="l", col="blue")
    lines(dataPiChinese$BIN_AVERAGE, dataPiChinese$PI, col="red3")
    legend("topright", c("British", "Han Chinese South"), lty=1, col=c("blue","red2"), bty="n")
  dev.off()        
q()
n
         